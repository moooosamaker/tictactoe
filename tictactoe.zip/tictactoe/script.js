const cells = document.querySelectorAll('[data-cell]');
const restartBtn = document.getElementById('restartBtn');
const popup = document.getElementById('popup');
const popupMessage = document.getElementById('popupMessage');
const closePopupBtn = document.getElementById('closePopup');

let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];

const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

function checkWin() {
    for (const combination of winningCombinations) {
        const [a, b, c] = combination;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            showPopup(`${board[a]} wins!`);
            return true;
        }
    }
    if (!board.includes('')) {
        showPopup("It's a draw!");
        return true;
    }
    return false;
}

function showPopup(message) {
    popupMessage.textContent = message;
    popup.style.display = 'block';
}

function handleClick(cell, index) {
    if (board[index]) return; // Prevent clicking on a filled cell

    board[index] = currentPlayer;
    cell.textContent = currentPlayer;

    if (checkWin()) return;

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X'; // Switch players
}

function restartGame() {
    board = ['', '', '', '', '', '', '', '', ''];
    cells.forEach(cell => cell.textContent = '');
    popup.style.display = 'none';
    currentPlayer = 'X';
}

cells.forEach((cell, index) => {
    cell.addEventListener('click', () => handleClick(cell, index));
});

restartBtn.addEventListener('click', restartGame);
closePopupBtn.addEventListener('click', () => popup.style.display = 'none');
